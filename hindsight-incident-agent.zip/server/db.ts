import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, Incident, InsertIncident, incidents, recommendationFeedback, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

type FeedbackRating = "helpful" | "needs_work";
export type RecommendationFeedback = { id: number; incidentId: number; rating: FeedbackRating; note: string | null; createdAt: Date };
let localFeedback: RecommendationFeedback[] = [];

const now = Date.now();
const seedRows: Array<Omit<InsertIncident, "id" | "createdAt" | "updatedAt">> = [
  {
    incidentCode: "INC-0015",
    title: "Repeated SSH failures followed by successful admin login",
    description: "42 failed SSH login attempts from 192.168.1.50 followed by one successful login to the production bastion.",
    logs: "sshd[1842]: Failed password for admin from 192.168.1.50 port 41220 ssh2\nsshd[1897]: Accepted password for admin from 192.168.1.50 port 41401 ssh2",
    errorMessages: "Authentication anomaly: burst of failures followed by successful privileged access",
    sourceIp: "192.168.1.50",
    target: "prod-bastion-01",
    username: "admin",
    severity: "high",
    status: "investigating",
    detectedAt: now - 1000 * 60 * 18,
    rootCause: null,
    investigation: null,
    recommendedActions: null,
    finalResolution: null,
    lessonsLearned: null,
    isHistorical: 0,
  },
  {
    incidentCode: "INC-0003",
    title: "SSH brute-force attack",
    description: "Repeated failed SSH authentication attempts against a privileged account from an unknown source.",
    logs: "42 failed attempts, one successful login, followed by shell activity under admin.",
    errorMessages: "Multiple failed logins detected",
    sourceIp: "185.220.101.14",
    target: "prod-bastion-01",
    username: "admin",
    severity: "high",
    status: "resolved",
    detectedAt: now - 1000 * 60 * 60 * 24 * 3,
    rootCause: "Weak administrator credentials",
    investigation: "Reviewed authentication logs; identified source IP; verified the successful login; checked commands executed after login.",
    recommendedActions: "Disable compromised account; block malicious IP; reset credentials; enable MFA.",
    finalResolution: "Account secured and unauthorized access removed.",
    lessonsLearned: "Enable MFA for every privileged account and alert on failure-to-success login bursts.",
    isHistorical: 1,
  },
  {
    incidentCode: "INC-0007",
    title: "Privileged credential compromise",
    description: "Successful login from a new geography with a password reused on another exposed service.",
    logs: "vpn-auth: login success from ASN 7922; impossible travel from last known session.",
    errorMessages: "New country and unfamiliar device fingerprint",
    sourceIp: "45.33.12.90",
    target: "identity-gateway",
    username: "svc-admin",
    severity: "high",
    status: "resolved",
    detectedAt: now - 1000 * 60 * 60 * 24 * 8,
    rootCause: "Password reuse on a breached third-party service",
    investigation: "Reviewed login history; checked source location; compared device fingerprint; examined authentication events.",
    recommendedActions: "Reset password; revoke active sessions; enable MFA; review recent admin actions.",
    finalResolution: "No further unauthorized activity detected after credential reset and session revocation.",
    lessonsLearned: "Use phishing-resistant MFA and block password reuse for privileged identities.",
    isHistorical: 1,
  },
  {
    incidentCode: "INC-0011",
    title: "Phishing attachment delivered to finance",
    description: "Malicious spreadsheet attachment triggered a macro execution chain on a finance workstation.",
    logs: "mail-gateway: attachment invoice_0927.xlsm; endpoint: WINWORD spawned powershell.exe",
    errorMessages: "Office child process policy violation",
    sourceIp: "mail-relay-external",
    target: "FIN-WS-044",
    username: "maria.chen",
    severity: "medium",
    status: "resolved",
    detectedAt: now - 1000 * 60 * 60 * 24 * 11,
    rootCause: "Malicious macro attachment bypassed email filtering",
    investigation: "Reviewed email headers; extracted attachment hash; traced child process tree; searched for lateral movement.",
    recommendedActions: "Quarantine email; isolate endpoint; reset credentials; block attachment hash.",
    finalResolution: "Email removed, endpoint reimaged, and sender indicators blocked.",
    lessonsLearned: "Disable macros from the internet and detonate unknown attachments before delivery.",
    isHistorical: 1,
  },
  {
    incidentCode: "INC-0012",
    title: "Suspicious PowerShell execution",
    description: "Encoded PowerShell launched from a user profile with outbound connection to a newly registered domain.",
    logs: "powershell.exe -enc JAB...; DNS query to update-cdn-support.com; process spawned by WINWORD",
    errorMessages: "Encoded command line and unsigned child process",
    sourceIp: "10.24.18.91",
    target: "ENG-LT-221",
    username: "dev-user",
    severity: "critical",
    status: "resolved",
    detectedAt: now - 1000 * 60 * 60 * 24 * 15,
    rootCause: "Malicious script executed from a weaponized document",
    investigation: "Decoded command; isolated endpoint; reviewed process tree; checked persistence locations and proxy logs.",
    recommendedActions: "Isolate endpoint; terminate process; block domain; collect memory image; rotate credentials.",
    finalResolution: "Endpoint isolated and rebuilt; malicious domain blocked; no persistence found.",
    lessonsLearned: "Alert on encoded PowerShell and keep endpoint isolation actions one click away.",
    isHistorical: 1,
  },
  {
    incidentCode: "INC-0013",
    title: "Malware execution from downloaded binary",
    description: "Unsigned executable downloaded from a shortened URL and launched by a standard user.",
    logs: "browser -> C:\\Users\\Public\\update.exe; sha256: 5a3...; outbound beacon every 60 seconds",
    errorMessages: "EDR malware verdict: trojan downloader",
    sourceIp: "10.24.8.17",
    target: "OPS-WS-102",
    username: "jordan.lee",
    severity: "high",
    status: "resolved",
    detectedAt: now - 1000 * 60 * 60 * 24 * 22,
    rootCause: "User downloaded and executed a trojanized utility",
    investigation: "Verified file hash; reviewed process activity; searched fleet for the hash; inspected persistence and DNS.",
    recommendedActions: "Isolate endpoint; remove malware; reset credentials; block hash and URL; hunt across fleet.",
    finalResolution: "Endpoint isolated, malware removed, and fleet-wide hash search returned no additional hits.",
    lessonsLearned: "Enforce application allow-listing for user-writable directories.",
    isHistorical: 1,
  },
];

let localIncidents: Incident[] = seedRows.map((row, index) => ({
  ...row,
  id: index + 1,
  createdAt: new Date(row.detectedAt ?? now),
  updatedAt: new Date(row.detectedAt ?? now),
})) as Incident[];

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  (['name', 'email', 'loginMethod'] as const).forEach(field => {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  });
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = 'admin';
    updateSet.role = 'admin';
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

async function ensureSeeded() {
  const db = await getDb();
  if (!db) return null;
  const existing = await db.select({ id: incidents.id }).from(incidents).limit(1);
  if (existing.length === 0) {
    await db.insert(incidents).values(seedRows);
  }
  return db;
}

export async function listIncidents() {
  const db = await ensureSeeded();
  if (!db) return [...localIncidents].sort((a, b) => b.detectedAt - a.detectedAt);
  return db.select().from(incidents).orderBy(desc(incidents.detectedAt));
}

export async function getIncidentById(id: number) {
  const db = await ensureSeeded();
  if (!db) return localIncidents.find(item => item.id === id);
  const rows = await db.select().from(incidents).where(eq(incidents.id, id)).limit(1);
  return rows[0];
}

export async function createIncident(values: Omit<InsertIncident, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) {
    const record = {
      ...values,
      id: Math.max(0, ...localIncidents.map(item => item.id)) + 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    } as Incident;
    localIncidents = [record, ...localIncidents];
    return record;
  }
  await db.insert(incidents).values(values);
  const rows = await db.select().from(incidents).where(eq(incidents.incidentCode, values.incidentCode)).limit(1);
  return rows[0];
}

export async function updateIncident(id: number, patch: Partial<InsertIncident>) {
  const db = await getDb();
  if (!db) {
    localIncidents = localIncidents.map(item => item.id === id ? ({ ...item, ...patch, updatedAt: new Date() } as Incident) : item);
    return localIncidents.find(item => item.id === id);
  }
  await db.update(incidents).set(patch).where(eq(incidents.id, id));
  const rows = await db.select().from(incidents).where(eq(incidents.id, id)).limit(1);
  return rows[0];
}

export async function recordRecommendationFeedback(values: { incidentId: number; rating: FeedbackRating; note?: string }) {
  const db = await getDb();
  if (!db) {
    const record: RecommendationFeedback = { id: localFeedback.length + 1, incidentId: values.incidentId, rating: values.rating, note: values.note ?? null, createdAt: new Date() };
    localFeedback = [record, ...localFeedback];
    return record;
  }
  await db.insert(recommendationFeedback).values({ incidentId: values.incidentId, rating: values.rating, note: values.note ?? null });
  const rows = await db.select().from(recommendationFeedback).orderBy(desc(recommendationFeedback.createdAt)).limit(1);
  return rows[0];
}
