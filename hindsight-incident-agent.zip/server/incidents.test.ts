import { describe, expect, it } from "vitest";
import { buildAnalysis, classifyIncidentType, memoryConfidence, similarityScore } from "./routers";
import { recordRecommendationFeedback } from "./db";

const current = {
  id: 20,
  incidentCode: "INC-0015",
  title: "Repeated SSH failures followed by successful admin login",
  description: "42 failed SSH attempts followed by a successful privileged login.",
  logs: "sshd failed password; sshd accepted password",
  errorMessages: "Authentication anomaly",
  sourceIp: "192.168.1.50",
  target: "prod-bastion-01",
  username: "admin",
  severity: "high" as const,
  status: "investigating" as const,
  detectedAt: Date.now(),
  rootCause: null,
  investigation: null,
  recommendedActions: null,
  finalResolution: null,
  lessonsLearned: null,
  isHistorical: 0,
  createdAt: new Date(),
  updatedAt: new Date(),
};

const sshMemory = {
  ...current,
  id: 3,
  incidentCode: "INC-0003",
  title: "SSH brute-force attack",
  description: "Repeated failed SSH authentication against admin followed by a successful login.",
  logs: "42 failed attempts and shell activity under admin",
  errorMessages: "Multiple failed logins detected",
  severity: "high" as const,
  status: "resolved" as const,
  rootCause: "Weak administrator credentials",
  investigation: "Reviewed authentication logs and post-login commands.",
  finalResolution: "Account secured and unauthorized access removed.",
  lessonsLearned: "Enable MFA for privileged accounts.",
  isHistorical: 1,
};

describe("Hindsight incident analysis", () => {
  it("ranks a matching SSH memory above an unrelated incident", () => {
    const unrelated = { ...sshMemory, id: 12, incidentCode: "INC-0012", title: "Suspicious PowerShell execution", description: "Encoded script launched from a document.", logs: "powershell -enc", errorMessages: "Encoded command" };
    expect(similarityScore(current, sshMemory)).toBeGreaterThan(similarityScore(current, unrelated));
  });

  it("builds evidence checks and proven actions from an SSH pattern", () => {
    const analysis = buildAnalysis(current, [current, sshMemory] as any);
    expect(analysis.pattern).toContain("SSH");
    expect(analysis.historical[0].incidentCode).toBe("INC-0003");
    expect(analysis.evidenceToCheck).toContain("Review SSH authentication logs around the first failure");
    expect(analysis.suggestedActions).toContain("Enable MFA for privileged access");
    expect(analysis.historical[0].finalResolution).toBe("Account secured and unauthorized access removed.");
    expect(analysis.historical[0].lessonsLearned).toBe("Enable MFA for privileged accounts.");
    expect(analysis.confidence).toBeGreaterThan(60);
  });
});


describe("Incident operations", () => {
  it("classifies alerts and calculates memory confidence for filters", () => {
    expect(classifyIncidentType(current)).toBe("credential");
    expect(classifyIncidentType({ ...current, title: "Malicious phishing attachment", description: "Email macro execution" })).toBe("phishing");
    expect(memoryConfidence(current, [current, sshMemory] as any)).toBeGreaterThan(0);
  });

  it("stores analyst feedback in the active persistence layer", async () => {
    const feedback = await recordRecommendationFeedback({ incidentId: current.id, rating: "helpful" });
    expect(feedback.incidentId).toBe(current.id);
    expect(feedback.rating).toBe("helpful");
  });
});
