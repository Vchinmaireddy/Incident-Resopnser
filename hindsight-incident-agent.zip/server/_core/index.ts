import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createIncident } from "../db";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  app.post("/api/webhooks/siem", async (req, res) => {
    const configuredSecret = process.env.SIEM_WEBHOOK_SECRET;
    if (configuredSecret && req.header("x-siem-webhook-secret") !== configuredSecret) {
      res.status(401).json({ success: false, error: "Invalid webhook secret" });
      return;
    }
    const payload = req.body?.alert ?? req.body?.event ?? req.body?.data ?? req.body ?? {};
    const title = String(payload.title ?? payload.name ?? payload.rule_name ?? "Incoming SIEM alert").slice(0, 180);
    const description = String(payload.description ?? payload.message ?? payload.summary ?? "Security alert received from SIEM webhook.").slice(0, 10000);
    const severityValue = String(payload.severity ?? payload.priority ?? "medium").toLowerCase();
    const severity = ["low", "medium", "high", "critical"].includes(severityValue) ? severityValue as "low" | "medium" | "high" | "critical" : "medium";
    const detectedAtValue = payload.detectedAt ?? payload.detected_at ?? payload.timestamp ?? Date.now();
    const parsedDate = typeof detectedAtValue === "number" ? detectedAtValue : Date.parse(String(detectedAtValue));
    const incident = await createIncident({
      incidentCode: `SIEM-${Date.now().toString().slice(-8)}`,
      title,
      description,
      logs: typeof payload.logs === "string" ? payload.logs : payload.raw ? JSON.stringify(payload.raw) : JSON.stringify(payload),
      errorMessages: payload.errorMessages ?? payload.error_message ?? payload.rule_id ?? "",
      sourceIp: payload.sourceIp ?? payload.source_ip ?? payload.src_ip ?? "",
      target: payload.target ?? payload.hostname ?? payload.asset ?? "",
      username: payload.username ?? payload.user ?? payload.user_name ?? "",
      severity,
      status: "new",
      detectedAt: Number.isFinite(parsedDate) ? parsedDate : Date.now(),
      rootCause: null,
      investigation: null,
      recommendedActions: null,
      finalResolution: null,
      lessonsLearned: null,
      isHistorical: 0,
    });
    res.status(201).json({ success: true, incident });
  });
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
