import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { createIncident, getIncidentById, listIncidents, recordRecommendationFeedback, updateIncident } from "./db";

const severitySchema = z.enum(["low", "medium", "high", "critical"]);
const statusSchema = z.enum(["new", "investigating", "contained", "resolved"]);

function tokens(value: string) {
  return new Set(value.toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter(word => word.length > 3));
}

export type IncidentType = "credential" | "phishing" | "endpoint" | "malware" | "access";

export function classifyIncidentType(incident: { title: string; description: string; logs?: string | null; errorMessages?: string | null }): IncidentType {
  const context = `${incident.title} ${incident.description} ${incident.logs ?? ""} ${incident.errorMessages ?? ""}`;
  if (/phishing|attachment|macro|email/i.test(context)) return "phishing";
  if (/ssh|credential|password|login|authentication|privilege|identity/i.test(context)) return "credential";
  if (/powershell|endpoint|process tree|script|execution/i.test(context)) return "endpoint";
  if (/malware|trojan|hash|executable|binary/i.test(context)) return "malware";
  return "access";
}

export function memoryConfidence(incident: { id: number; title: string; description: string; logs?: string | null; errorMessages?: string | null }, allIncidents: Array<{ id: number; title: string; description: string; logs?: string | null; errorMessages?: string | null; isHistorical?: number; status?: string }>) {
  const historical = allIncidents.filter(item => item.id !== incident.id && (item.isHistorical === 1 || item.status === "resolved"));
  if (!historical.length) return 0;
  return Math.round(Math.max(...historical.map(item => similarityScore(incident, item))) * 100);
}

export function similarityScore(current: { title: string; description: string; logs?: string | null; errorMessages?: string | null }, candidate: { title: string; description: string; logs?: string | null; errorMessages?: string | null }) {
  const left = tokens([current.title, current.description, current.logs, current.errorMessages].filter(Boolean).join(" "));
  const right = tokens([candidate.title, candidate.description, candidate.logs, candidate.errorMessages].filter(Boolean).join(" "));
  const shared = Array.from(left).filter(word => right.has(word));
  const phraseBoost = /ssh|login|credential|powershell|phishing|malware|endpoint/i.test(current.title + current.description) && /ssh|login|credential|powershell|phishing|malware|endpoint/i.test(candidate.title + candidate.description) ? 0.18 : 0;
  return Math.min(0.98, Math.max(0.2, shared.length / Math.max(6, left.size) + phraseBoost));
}

export function buildAnalysis(incident: NonNullable<Awaited<ReturnType<typeof getIncidentById>>>, allIncidents: Awaited<ReturnType<typeof listIncidents>>) {
  const context = `${incident.title} ${incident.description} ${incident.logs ?? ""} ${incident.errorMessages ?? ""}`;
  const isSsh = /ssh|login|authentication|password|admin/i.test(context);
  const isPhishing = /phishing|attachment|macro|email/i.test(context);
  const isPowerShell = /powershell|encoded|script/i.test(context);
  const isMalware = /malware|trojan|hash|executable|binary/i.test(context);

  const pattern = isSsh ? "credential abuse / SSH brute force" : isPhishing ? "phishing delivery and execution" : isPowerShell ? "script-based endpoint compromise" : isMalware ? "malware execution" : "suspicious access pattern";
  const likelyRootCause = isSsh ? "Compromised or weak privileged credentials are the leading hypothesis." : isPhishing ? "A malicious attachment or macro likely bypassed delivery controls." : isPowerShell ? "A weaponized document or user-writable script likely launched the encoded command." : isMalware ? "An unsigned or trojanized binary likely reached a user-writable execution path." : "The signal is consistent with an identity or endpoint control gap; validate the initial access path.";

  const evidenceToCheck = isSsh
    ? ["Review SSH authentication logs around the first failure", "Validate source IP reputation, ASN, and prior activity", "Confirm whether the successful session was legitimate", "Review commands and files touched after authentication"]
    : isPhishing
      ? ["Preserve email headers and attachment hash", "Trace the process tree from the document", "Search the mailbox and fleet for matching indicators", "Confirm whether credentials or tokens were exposed"]
      : isPowerShell
        ? ["Decode the command and capture the full process tree", "Isolate the endpoint if execution is confirmed", "Review persistence locations and proxy/DNS logs", "Hunt for the domain or hash across the fleet"]
        : ["Validate the alert against raw telemetry", "Scope the indicator across identities and endpoints", "Check for persistence and lateral movement", "Preserve evidence before containment changes"];

  const suggestedActions = isSsh
    ? ["Disable or step-up authenticate the affected account", "Reset credentials and revoke active sessions", "Block the source IP after confirming malicious intent", "Enable MFA for privileged access"]
    : isPhishing
      ? ["Quarantine the message and related variants", "Isolate the endpoint and collect the attachment hash", "Reset credentials if execution occurred", "Block sender, hash, and infrastructure indicators"]
      : ["Contain the affected endpoint or identity", "Preserve volatile evidence and relevant logs", "Block confirmed indicators at the control point", "Rotate exposed credentials and monitor for recurrence"];

  const historical = allIncidents
    .filter(item => item.id !== incident.id && (item.isHistorical === 1 || item.status === "resolved"))
    .map(item => ({ ...item, matchScore: similarityScore(incident, item) }))
    .sort((a, b) => b.matchScore - a.matchScore)
    .slice(0, 3);

  const confidence = historical.length ? Math.round(Math.min(94, 62 + historical[0].matchScore * 35)) : 54;
  return {
    pattern,
    likelyRootCause,
    confidence,
    evidenceToCheck,
    suggestedActions,
    historical,
    summary: `The signal most closely resembles ${pattern}. Hindsight found ${historical.length} relevant memory record${historical.length === 1 ? "" : "s"} to anchor the next investigation steps.`,
  };
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  incidents: router({
    dashboard: publicProcedure.query(async () => {
      const records = await listIncidents();
      const active = records.filter(item => item.status !== "resolved");
      const historical = records.filter(item => item.isHistorical === 1 || item.status === "resolved");
      const highRisk = active.filter(item => item.severity === "high" || item.severity === "critical").length;
      return {
        incidents: records.map(item => ({ ...item, incidentType: classifyIncidentType(item), memoryConfidence: memoryConfidence(item, records) })),
        stats: {
          active: active.length,
          historical: historical.length,
          highRisk,
          memoryCoverage: Math.min(100, Math.round((historical.length / Math.max(1, records.length)) * 100)),
        },
      };
    }),
    create: publicProcedure.input(z.object({
      title: z.string().min(3),
      description: z.string().min(8),
      logs: z.string().optional().default(""),
      errorMessages: z.string().optional().default(""),
      severity: severitySchema,
      detectedAt: z.number(),
      sourceIp: z.string().optional().default(""),
      target: z.string().optional().default(""),
      username: z.string().optional().default(""),
    })).mutation(async ({ input }) => {
      const incidentCode = `INC-${String(Date.now()).slice(-4)}`;
      return createIncident({
        ...input,
        incidentCode,
        status: "new",
        rootCause: null,
        investigation: null,
        recommendedActions: null,
        finalResolution: null,
        lessonsLearned: null,
        isHistorical: 0,
      });
    }),
    analyze: publicProcedure.input(z.object({ incidentId: z.number() })).mutation(async ({ input }) => {
      const incident = await getIncidentById(input.incidentId);
      if (!incident) throw new Error("Incident not found");
      const allIncidents = await listIncidents();
      return buildAnalysis(incident, allIncidents);
    }),
    resolve: publicProcedure.input(z.object({
      incidentId: z.number(),
      rootCause: z.string().min(4),
      investigation: z.string().min(4),
      finalResolution: z.string().min(4),
      lessonsLearned: z.string().min(4),
    })).mutation(async ({ input }) => {
      return updateIncident(input.incidentId, {
        rootCause: input.rootCause,
        investigation: input.investigation,
        finalResolution: input.finalResolution,
        lessonsLearned: input.lessonsLearned,
        status: "resolved",
        isHistorical: 1,
      });
    }),
    updateStatus: publicProcedure.input(z.object({ incidentId: z.number(), status: statusSchema })).mutation(async ({ input }) => {
      return updateIncident(input.incidentId, { status: input.status });
    }),
    feedback: publicProcedure.input(z.object({ incidentId: z.number(), rating: z.enum(["helpful", "needs_work"]), note: z.string().max(500).optional() })).mutation(async ({ input }) => {
      const incident = await getIncidentById(input.incidentId);
      if (!incident) throw new Error("Incident not found");
      return recordRecommendationFeedback(input);
    }),
  }),
});

export type AppRouter = typeof appRouter;
