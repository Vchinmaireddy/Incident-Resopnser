import {
  Activity,
  ArrowRight,
  BrainCircuit,
  CheckCircle2,
  Command,
  History,
  LockKeyhole,
  Shield,
  UserPlus,
  X,
  Sparkles,
} from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { startLogin } from "@/const";

const paths = [
  {
    icon: Activity,
    eyebrow: "Live response",
    title: "Investigate a signal",
    copy: "Open the active queue and give your analyst team the context to act with confidence.",
    href: "/console",
    action: "Open command center",
  },
  {
    icon: BrainCircuit,
    eyebrow: "Operational memory",
    title: "Explore what your team learned",
    copy: "Browse resolved incidents, root causes, and proven actions before the next alert arrives.",
    href: "/console?view=memory",
    action: "Explore Hindsight memory",
  },
];

export default function Landing() {
  const [authOpen, setAuthOpen] = useState(() => new URLSearchParams(window.location.search).get("auth") === "login");

  return (
    <main className="landing-page">
      <nav className="landing-nav" aria-label="Primary navigation">
        <Link href="/" className="landing-brand" aria-label="Hindsight home">
          <span className="brand-mark"><Shield size={17} /></span>
          <span><strong>Hindsight</strong><small>Incident response agent</small></span>
        </Link>
        <div className="landing-nav-right">
          <span className="landing-nav-note">Operational memory for security teams</span>
          <button className="landing-nav-link landing-auth-trigger" onClick={() => setAuthOpen(true)}>Sign in / Register <ArrowRight size={14} /></button>
        </div>
      </nav>

      <section className="landing-hero">
        <div className="landing-copy">
          <div className="eyebrow"><span className="pulse" /> Memory-backed incident response</div>
          <h1>Respond faster because your team remembers.</h1>
          <p className="landing-lede">Hindsight turns every resolved incident into practical context for the next one — so analysts investigate with precedent, not a blank chat window.</p>
          <div className="landing-actions">
            <Link href="/console" className="primary-button landing-cta"><Command size={15} /> Enter command center <ArrowRight size={15} /></Link>
            <a href="#choose-path" className="secondary-button landing-cta">See your options <ArrowRight size={15} /></a>
          </div>
          <div className="landing-proof"><span><CheckCircle2 size={14} /> Structured incident memory</span><span><CheckCircle2 size={14} /> AI-assisted investigations</span></div>
        </div>

        <div className="landing-visual" aria-label="Hindsight command center preview">
          <div className="landing-visual-top"><span className="visual-kicker">HINDSIGHT / COMMAND CENTER</span><span className="status-chip resolved">memory online</span></div>
          <div className="visual-title-row"><div><span className="visual-label">Current focus</span><strong>Repeated SSH failures</strong></div><span className="severity high">High</span></div>
          <div className="visual-signal"><div className="signal-icon"><Activity size={16} /></div><div><strong>1 active incident</strong><span>42 failed attempts · 1 successful login</span></div><span className="visual-live">LIVE</span></div>
          <div className="visual-memory"><div className="visual-memory-head"><span><BrainCircuit size={14} /> Hindsight recall</span><span>5 cases</span></div><div className="visual-match"><div className="match-score">96%</div><div><strong>SSH brute-force attack</strong><span>Weak administrator credentials</span></div><History size={15} /></div><div className="visual-match"><div className="match-score">88%</div><div><strong>Privileged credential compromise</strong><span>Password reuse on third-party service</span></div><History size={15} /></div></div>
          <div className="visual-footer"><Sparkles size={14} /><span>Recommended next step</span><strong>Run AI investigation</strong></div>
        </div>
      </section>

      <section className="landing-story" aria-label="How Hindsight works">
        <div><span className="section-index">01 / THE LOOP</span><h2>Every incident makes the next response sharper.</h2></div>
        <div className="story-steps"><div><span>01</span><strong>Capture the signal</strong><p>Bring the alert, evidence, and identity context into one workspace.</p></div><div><span>02</span><strong>Recall what worked</strong><p>Compare against resolved incidents and patterns your team already knows.</p></div><div><span>03</span><strong>Close the loop</strong><p>Store the root cause and final action as future-ready memory.</p></div></div>
      </section>

      <section className="landing-options" id="choose-path">
        <div className="landing-options-head"><div><span className="section-index">02 / CHOOSE A PATH</span><h2>Where would you like to start?</h2></div><p>Jump straight into the workflow that matches what you need right now.</p></div>
        <div className="landing-path-grid">{paths.map(path => { const Icon = path.icon; return <Link key={path.title} href={path.href} className="landing-path-card"><div className="path-card-icon"><Icon size={18} /></div><div><span className="section-index">{path.eyebrow}</span><h3>{path.title}</h3><p>{path.copy}</p><span className="path-card-action">{path.action} <ArrowRight size={14} /></span></div></Link>; })}</div>
      </section>

      <footer className="landing-footer"><span>Hindsight / Incident response agent</span><span>Make the next investigation better than the last.</span></footer>

      {authOpen && <div className="auth-modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) setAuthOpen(false); }}>
        <section className="auth-modal" role="dialog" aria-modal="true" aria-labelledby="auth-modal-title">
          <button className="icon-button auth-modal-close" onClick={() => setAuthOpen(false)} aria-label="Close login and registration"><X size={16} /></button>
          <div className="auth-modal-icon"><LockKeyhole size={18} /></div>
          <span className="section-index">HINDSIGHT / SECURE ACCESS</span>
          <h2 id="auth-modal-title">Start with the right context.</h2>
          <p>Sign in to your analyst workspace or create a new account to begin building operational memory.</p>
          <div className="auth-modal-actions">
            <button className="primary-button" onClick={() => startLogin("signIn")}><LockKeyhole size={15} /> Log in <ArrowRight size={14} /></button>
            <button className="secondary-button" onClick={() => startLogin("signUp")}><UserPlus size={15} /> Register <ArrowRight size={14} /></button>
          </div>
          <span className="auth-modal-note">Secure OAuth access · no password stored in Hindsight</span>
        </section>
      </div>}
    </main>
  );
}
