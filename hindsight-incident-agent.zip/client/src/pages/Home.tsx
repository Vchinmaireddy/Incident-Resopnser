import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  BrainCircuit,
  Check,
  CheckCircle2,
  ChevronRight,
  ChevronDown,
  LogIn,
  LogOut,
  UserRound,
  Clock3,
  Command,
  FileSearch,
  Fingerprint,
  FlaskConical,
  History,
  LayoutDashboard,
  Library,
  LockKeyhole,
  Menu,
  Network,
  Plus,
  Radar,
  RefreshCw,
  Search,
  Send,
  Shield,
  ShieldAlert,
  Sparkles,
  TerminalSquare,
  X,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

type View = "overview" | "memory" | "runbooks" | "learning";
type Severity = "low" | "medium" | "high" | "critical";

type FormState = {
  title: string;
  description: string;
  logs: string;
  errorMessages: string;
  severity: Severity;
  detectedAt: string;
  sourceIp: string;
  target: string;
  username: string;
};

const severityLabel: Record<string, string> = { low: "Low", medium: "Medium", high: "High", critical: "Critical" };
const initialForm: FormState = {
  title: "",
  description: "",
  logs: "",
  errorMessages: "",
  severity: "high",
  detectedAt: new Date().toISOString().slice(0, 16),
  sourceIp: "",
  target: "",
  username: "",
};

function formatTime(value: number | Date) {
  return new Date(value).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

function formatAge(value: number) {
  const minutes = Math.max(1, Math.round((Date.now() - value) / 60000));
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

function SeverityPill({ severity }: { severity: string }) {
  return <span className={`severity ${severity}`}>{severityLabel[severity] ?? severity}</span>;
}

function StatusPill({ status }: { status: string }) {
  return <span className={`status-chip ${status}`}>{status}</span>;
}

export default function Home() {
  const requestedView = new URLSearchParams(window.location.search).get("view");
  const initialView: View = requestedView === "memory" || requestedView === "runbooks" || requestedView === "learning" ? requestedView : "overview";
  const [view, setView] = useState<View>(initialView);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [analysis, setAnalysis] = useState<any>(null);
  const [analysisTab, setAnalysisTab] = useState<"investigate" | "resolve">("investigate");
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState<FormState>(initialForm);
  const [resolution, setResolution] = useState({ rootCause: "", investigation: "", finalResolution: "", lessonsLearned: "" });
  const [filters, setFilters] = useState({ type: "all", severity: "all", confidence: "0" });
  const [feedbackState, setFeedbackState] = useState<Record<number, "helpful" | "needs_work">>({});
  const [accountOpen, setAccountOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();

  const dashboard = trpc.incidents.dashboard.useQuery(undefined, { staleTime: 30_000 });
  const utils = trpc.useUtils();
  const analyzeMutation = trpc.incidents.analyze.useMutation({
    onSuccess: result => {
      setAnalysis(result);
      toast.success("Hindsight analysis ready", { description: `${result.historical.length} historical matches found.` });
    },
    onError: error => toast.error("Analysis failed", { description: error.message }),
  });
  const createMutation = trpc.incidents.create.useMutation({
    onSuccess: created => {
      setCreateOpen(false);
      setForm(initialForm);
      setSelectedId(created.id);
      setAnalysis(null);
      void utils.incidents.dashboard.invalidate();
      toast.success(`${created.incidentCode} added to the active queue`);
    },
    onError: error => toast.error("Could not create incident", { description: error.message }),
  });
  const resolveMutation = trpc.incidents.resolve.useMutation({
    onSuccess: resolved => {
      setAnalysisTab("investigate");
      setResolution({ rootCause: "", investigation: "", finalResolution: "", lessonsLearned: "" });
      void utils.incidents.dashboard.invalidate();
      toast.success(`${resolved?.incidentCode ?? "Incident"} stored in Hindsight`, { description: "The resolution is now available for future investigations." });
    },
    onError: error => toast.error("Could not store learning", { description: error.message }),
  });
  const statusMutation = trpc.incidents.updateStatus.useMutation({
    onSuccess: () => void utils.incidents.dashboard.invalidate(),
    onError: error => toast.error("Could not update status", { description: error.message }),
  });
  const feedbackMutation = trpc.incidents.feedback.useMutation({
    onSuccess: (_result, variables) => {
      setFeedbackState(previous => ({ ...previous, [variables.incidentId]: variables.rating }));
      toast.success(variables.rating === "helpful" ? "Thanks — this guidance was useful." : "Thanks — we’ll mark this for improvement.");
    },
    onError: error => toast.error("Could not save feedback", { description: error.message }),
  });

  const records = dashboard.data?.incidents ?? [];
  const active = useMemo(() => records.filter(item => item.status !== "resolved"), [records]);
  const historical = useMemo(() => records.filter(item => item.isHistorical === 1 || item.status === "resolved"), [records]);
  const filteredRecords = useMemo(() => records.filter(item => {
    const typeMatch = filters.type === "all" || item.incidentType === filters.type;
    const severityMatch = filters.severity === "all" || item.severity === filters.severity;
    const confidenceMatch = Number(item.memoryConfidence ?? 0) >= Number(filters.confidence);
    return typeMatch && severityMatch && confidenceMatch;
  }), [records, filters]);
  const visibleActive = useMemo(() => filteredRecords.filter(item => item.status !== "resolved"), [filteredRecords]);
  const visibleHistorical = useMemo(() => filteredRecords.filter(item => item.isHistorical === 1 || item.status === "resolved"), [filteredRecords]);
  const selected = filteredRecords.find(item => item.id === selectedId) ?? visibleActive[0] ?? visibleHistorical[0];

  useEffect(() => {
    if (selectedId === null && visibleActive[0]) setSelectedId(visibleActive[0].id);
  }, [visibleActive, selectedId]);

  useEffect(() => {
    if (selected && selectedId === null) setSelectedId(selected.id);
  }, [selected, selectedId]);

  const selectIncident = (id: number) => {
    setSelectedId(id);
    setAnalysis(null);
    setAnalysisTab("investigate");
  };

  const runAnalysis = () => {
    if (!selected) return;
    analyzeMutation.mutate({ incidentId: selected.id });
  };

  const submitIncident = (event: React.FormEvent) => {
    event.preventDefault();
    createMutation.mutate({
      ...form,
      detectedAt: new Date(form.detectedAt).getTime(),
    });
  };

  const submitResolution = (event: React.FormEvent) => {
    event.preventDefault();
    if (!selected) return;
    resolveMutation.mutate({ incidentId: selected.id, ...resolution });
  };

  const showView = (next: View) => {
    setView(next);
    if (next === "overview") setAnalysisTab("investigate");
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Shield size={17} /></div>
          <div><div className="brand-title">Hindsight</div><div className="brand-kicker">Incident response agent</div></div>
        </div>

        <div className="nav-label">Workspace</div>
        <nav className="nav-list" aria-label="Workspace navigation">
          <button className={`nav-button ${view === "overview" ? "active" : ""}`} onClick={() => showView("overview")}><LayoutDashboard size={15} /> Overview <span className="count">{active.length}</span></button>
          <button className={`nav-button ${view === "memory" ? "active" : ""}`} onClick={() => showView("memory")}><Library size={15} /> Hindsight memory <span className="count">{historical.length}</span></button>
          <button className={`nav-button ${view === "runbooks" ? "active" : ""}`} onClick={() => showView("runbooks")}><Command size={15} /> Runbooks <span className="count">04</span></button>
          <button className={`nav-button ${view === "learning" ? "active" : ""}`} onClick={() => showView("learning")}><Sparkles size={15} /> Learning loop</button>
        </nav>

        <div className="memory-rail">
          <div className="memory-rail-head"><span className="memory-rail-title">Memory is live</span><BrainCircuit size={13} color="var(--accent)" /></div>
          <div className="memory-orbit"><div className="orbit-dot one" /><div className="orbit-dot two" /><div className="orbit-dot three" /><div className="orbit-core"><BrainCircuit size={18} /></div></div>
          <div className="rail-foot">New signals are compared against resolved incidents, root causes, and actions that worked.</div>
        </div>
        <div className="sidebar-account">
          <button className="sidebar-user" onClick={() => setAccountOpen(value => !value)} aria-expanded={accountOpen} aria-haspopup="menu">
            <div className="avatar">{user?.name?.slice(0, 2).toUpperCase() || "AR"}</div><div className="user-meta"><strong>{user?.name || "Alex Rivera"}</strong><span>{isAuthenticated ? "SOC analyst · on-call" : "Preview analyst · sign in"}</span></div><ChevronDown size={13} color="var(--success)" style={{ marginLeft: "auto", transform: accountOpen ? "rotate(180deg)" : undefined }} />
          </button>
          {accountOpen && <div className="account-menu" role="menu">
            <div className="account-menu-head"><UserRound size={14} /><div><strong>{isAuthenticated ? "Account connected" : "Preview workspace"}</strong><span>{isAuthenticated ? "Your session is active" : "Sign in to save your work"}</span></div></div>
            {isAuthenticated ? <button className="account-menu-item danger" onClick={() => { void logout(); setAccountOpen(false); }} role="menuitem"><LogOut size={14} /> Log out</button> : <button className="account-menu-item" onClick={() => { window.location.href = "/?auth=login"; }} role="menuitem"><LogIn size={14} /> Log in or register</button>}
          </div>}
        </div>
      </aside>

      <main className="main-canvas">
        <header className="topbar">
          <div className="breadcrumb"><strong>SOC /</strong> {view === "overview" ? "command center" : view === "memory" ? "hindsight memory" : view === "runbooks" ? "response runbooks" : "learning loop"}</div>
          <div className="topbar-actions"><button className="icon-button" aria-label="Search"><Search size={15} /></button><button className="icon-button" aria-label="Refresh" onClick={() => void dashboard.refetch()}><RefreshCw size={15} /></button><button className="primary-button" onClick={() => setCreateOpen(true)}><Plus size={15} /> New incident</button></div>
        </header>

        {!dashboard.isLoading && <div className="filter-bar" aria-label="Incident filters">
          <div className="filter-label"><Search size={13} /> Filter queue</div>
          <label>Type<select value={filters.type} onChange={event => setFilters({ ...filters, type: event.target.value })}><option value="all">All types</option><option value="credential">Credential</option><option value="phishing">Phishing</option><option value="endpoint">Endpoint</option><option value="malware">Malware</option><option value="access">Access</option></select></label>
          <label>Severity<select value={filters.severity} onChange={event => setFilters({ ...filters, severity: event.target.value })}><option value="all">All severities</option><option value="critical">Critical</option><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select></label>
          <label>Memory confidence<select value={filters.confidence} onChange={event => setFilters({ ...filters, confidence: event.target.value })}><option value="0">Any match</option><option value="50">50%+</option><option value="70">70%+</option><option value="85">85%+</option></select></label>
          {(filters.type !== "all" || filters.severity !== "all" || filters.confidence !== "0") && <button className="filter-clear" onClick={() => setFilters({ type: "all", severity: "all", confidence: "0" })}>Clear filters</button>}
        </div>}

        {dashboard.isLoading ? <div style={{ paddingTop: 26 }}><div className="loading-skeleton" /></div> : view === "overview" ? (
          <>
            <section className="page-heading"><div><div className="eyebrow"><span className="pulse" /> Operational memory online</div><h1>Incident command center</h1><p className="subhead">Investigate what is happening now with the context of what your team already learned.</p></div><div style={{ display: "flex", gap: 8, alignItems: "center" }}><span className="status-chip investigating"><Activity size={11} /> live monitoring</span></div></section>
            <section className="stats-grid" aria-label="Incident metrics">
              <div className="stat-card accent"><div className="stat-top"><span>Active incidents</span><AlertTriangle className="stat-icon" size={14} /></div><div className="stat-value">{dashboard.data?.stats.active ?? 0}<small>needs attention</small></div></div>
              <div className="stat-card"><div className="stat-top"><span>Previous incidents</span><History className="stat-icon" size={14} /></div><div className="stat-value">{dashboard.data?.stats.historical ?? 0}<small>in memory</small></div></div>
              <div className="stat-card"><div className="stat-top"><span>High severity</span><ShieldAlert className="stat-icon" size={14} /></div><div className="stat-value">{dashboard.data?.stats.highRisk ?? 0}<small>active now</small></div></div>
              <div className="stat-card"><div className="stat-top"><span>Memory coverage</span><BrainCircuit className="stat-icon" size={14} /></div><div className="stat-value">{dashboard.data?.stats.memoryCoverage ?? 0}%<small>context ready</small></div></div>
            </section>

            <section className="memory-banner"><div><div className="memory-banner-title"><BrainCircuit size={17} /> Hindsight memory</div><p className="memory-banner-copy">The investigation starts with precedent, not a blank chat window.</p></div><div className="memory-flow"><div className="flow-node"><span>Signal</span><strong>new alert</strong></div><div className="flow-node"><span>Recall</span><strong>{historical.length} cases</strong></div><div className="flow-node"><span>Compare</span><strong>root causes</strong></div><div className="flow-node"><span>Respond</span><strong>next actions</strong></div></div></section>

            <section className="workspace-grid">
              <div className="panel"><div className="panel-head"><div className="panel-head-copy"><BrainCircuit size={14} /><div><div className="panel-kicker">Hindsight memory</div><h2>Recent recall</h2></div></div><button className="icon-button" onClick={() => showView("memory")} aria-label="Open memory"><ArrowUpRight size={14} /></button></div><div className="panel-body"><div className="memory-list">{visibleHistorical.slice(0, 4).map(item => <button key={item.id} className={`memory-item ${selected?.id === item.id ? "selected" : ""}`} onClick={() => selectIncident(item.id)} style={{ textAlign: "left" }}><div className="item-row"><span className="item-code">{item.incidentCode}</span><SeverityPill severity={item.severity} /></div><div className="item-title">{item.title}</div><div className="item-meta"><span>{formatAge(item.detectedAt)}</span><span>·</span><span>{item.rootCause ? "root cause known" : "unresolved"}</span></div></button>)}</div></div></div>

              <div className="panel"><div className="panel-head"><div className="panel-head-copy"><Radar size={14} /><div><div className="panel-kicker">Live queue</div><h2>Active incidents</h2></div></div><span className="status-chip investigating">{visibleActive.length} open</span></div><div className="panel-body"><div className="queue-list">{visibleActive.length ? visibleActive.map(item => <button key={item.id} className={`queue-card ${selected?.id === item.id ? "selected" : ""}`} onClick={() => selectIncident(item.id)} style={{ textAlign: "left" }}><div className="item-row"><span className="item-code">{item.incidentCode}</span><StatusPill status={item.status} /></div><h3 style={{ marginTop: 7, color: "var(--text-strong)", lineHeight: 1.3 }}>{item.title}</h3><p>{item.description}</p><div className="item-meta"><SeverityPill severity={item.severity} /><span>{formatTime(item.detectedAt)}</span></div></button>) : <div className="empty-state"><CheckCircle2 size={23} /><div>No active incidents. Your queue is clear.</div></div>}</div><div style={{ marginTop: 12, display: "flex", justifyContent: "center" }}><button className="secondary-button" onClick={() => setCreateOpen(true)}><Plus size={13} /> Add incoming signal</button></div></div></div>

              {selected && <div className="panel detail-panel"><div className="detail-head"><div className="item-row"><span className="item-code">{selected.incidentCode} · detected {formatAge(selected.detectedAt)}</span><SeverityPill severity={selected.severity} /></div><div className="detail-title">{selected.title}</div><p className="detail-desc">{selected.description}</p><div className="item-meta"><span><TerminalSquare size={11} /> {selected.target || "target unknown"}</span><span>·</span><span><Fingerprint size={11} /> {selected.username || "identity unknown"}</span></div></div><div className="detail-tabs"><button className={`tab ${analysisTab === "investigate" ? "active" : ""}`} onClick={() => setAnalysisTab("investigate")}>AI investigation</button><button className={`tab ${analysisTab === "resolve" ? "active" : ""}`} onClick={() => setAnalysisTab("resolve")}>Resolution + learning</button></div>{analysisTab === "investigate" ? <div className="panel-body">
                {!analysis ? <><div className="analysis-status"><div className="status-icon"><BrainCircuit size={15} /></div><div><strong>Ready to reason from memory</strong><span>Compare this signal against previous incidents and proven actions.</span></div></div><div className="analysis-block"><div className="analysis-block-head"><span>Memory context</span><span>{historical.length} records available</span></div><div className="match-list">{historical.slice(0, 2).map(item => <div key={item.id} className="match-row"><div className="match-score">{item.isHistorical ? "MEM" : "LIVE"}</div><div><strong>{item.incidentCode} · {item.title}</strong><span>{item.rootCause || "Root cause pending"}</span></div><ChevronRight size={14} color="#718893" /></div>)}</div></div><button className="primary-button" style={{ width: "100%", marginTop: 15 }} onClick={runAnalysis} disabled={analyzeMutation.isPending}><Sparkles size={14} /> {analyzeMutation.isPending ? "Analyzing signal…" : "Run AI investigation"}</button></> : <><div className="analysis-status"><div className="status-icon"><CheckCircle2 size={15} /></div><div><strong>{analysis.pattern}</strong><span>{analysis.confidence}% confidence · Hindsight-backed</span></div></div><div className="analysis-block"><div className="analysis-block-head"><span>Analyst brief</span><span>root cause hypothesis</span></div><p className="analysis-copy">{analysis.summary} {analysis.likelyRootCause}</p></div><div className="analysis-block"><div className="analysis-block-head"><span>Similar incidents</span><span>match score</span></div><div className="match-list">{analysis.historical.map((item: any) => <div key={item.id} className="match-row"><div className="match-score">{Math.round(item.matchScore * 100)}%</div><div><strong>{item.incidentCode} · {item.title}</strong><span>{item.rootCause || "Root cause pending"}</span></div><ChevronRight size={14} color="#718893" /></div>)}</div></div><div className="analysis-block"><div className="analysis-block-head"><span>Investigation steps</span><span>evidence to check</span></div><div className="evidence-list">{analysis.evidenceToCheck.map((step: string) => <div className="check-row" key={step}><Check size={13} />{step}</div>)}</div></div><div className="analysis-block"><div className="analysis-block-head"><span>Previous resolutions</span><span>what worked before</span></div><div className="resolution-list">{analysis.historical.filter((item: any) => item.finalResolution || item.lessonsLearned).map((item: any) => <div className="resolution-row" key={`resolution-${item.id}`}><div className="resolution-row-head"><strong>{item.incidentCode} · {item.title}</strong><History size={13} /></div><p>{item.finalResolution || "Resolution details pending"}</p>{item.lessonsLearned && <span>Lesson: {item.lessonsLearned}</span>}</div>)}</div></div><div className="analysis-block"><div className="analysis-block-head"><span>Suggested actions</span><span>used before</span></div><div className="action-list">{analysis.suggestedActions.slice(0, 3).map((action: string) => <div className="check-row" key={action}><Zap size={12} />{action}</div>)}</div></div><div className="feedback-row"><span>Was this guidance useful?</span><div><button className={`feedback-button ${feedbackState[selected.id] === "helpful" ? "selected" : ""}`} onClick={() => feedbackMutation.mutate({ incidentId: selected.id, rating: "helpful" })} disabled={feedbackMutation.isPending}>Helpful</button><button className={`feedback-button ${feedbackState[selected.id] === "needs_work" ? "selected negative" : ""}`} onClick={() => feedbackMutation.mutate({ incidentId: selected.id, rating: "needs_work" })} disabled={feedbackMutation.isPending}>Needs work</button></div></div><button className="secondary-button" style={{ width: "100%", marginTop: 15 }} onClick={() => setAnalysisTab("resolve")}><CheckCircle2 size={14} /> Capture resolution</button></>}
              </div> : <form className="panel-body" onSubmit={submitResolution}><div className="analysis-status"><div className="status-icon"><Library size={15} /></div><div><strong>Close the loop</strong><span>What actually fixed this issue becomes future context.</span></div></div><div className="form-grid" style={{ gridTemplateColumns: "1fr", marginTop: 14 }}><div className="form-field"><label>Final root cause</label><textarea required value={resolution.rootCause} onChange={event => setResolution({ ...resolution, rootCause: event.target.value })} placeholder="e.g. Weak admin credential exposed by password reuse" /></div><div className="form-field"><label>Investigation steps taken</label><textarea required value={resolution.investigation} onChange={event => setResolution({ ...resolution, investigation: event.target.value })} placeholder="Evidence checked, scope confirmed, and what ruled out" /></div><div className="form-field"><label>What actually fixed it</label><textarea required value={resolution.finalResolution} onChange={event => setResolution({ ...resolution, finalResolution: event.target.value })} placeholder="The containment and remediation that stopped the issue" /></div><div className="form-field"><label>Lesson for Hindsight</label><textarea required value={resolution.lessonsLearned} onChange={event => setResolution({ ...resolution, lessonsLearned: event.target.value })} placeholder="A future analyst should remember…" /></div></div><button className="primary-button" style={{ width: "100%", marginTop: 15 }} disabled={resolveMutation.isPending}><Library size={14} /> {resolveMutation.isPending ? "Storing memory…" : "Resolve + store in Hindsight"}</button></form>}<div className="detail-actions">{selected.status !== "contained" && selected.status !== "resolved" && <button className="secondary-button" onClick={() => statusMutation.mutate({ incidentId: selected.id, status: "contained" })}><Shield size={13} /> Mark contained</button>}<button className="secondary-button" onClick={() => setAnalysisTab("resolve")}><History size={13} /> Add learning</button></div></div>}
            </section>
          </>
        ) : view === "memory" ? <MemoryView incidents={visibleHistorical} onSelect={selectIncident} onBack={() => showView("overview")} /> : view === "runbooks" ? <RunbooksView /> : <LearningView incidents={visibleHistorical} />}
      </main>

      {createOpen && <div className="drawer-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) setCreateOpen(false); }}><aside className="drawer" role="dialog" aria-modal="true" aria-labelledby="new-incident-title"><div className="drawer-header"><div><div className="eyebrow"><span className="pulse" /> Intake signal</div><h2 id="new-incident-title">Create incident</h2><p>Give the agent enough signal to match this incident to what your team has already seen.</p></div><button className="icon-button" onClick={() => setCreateOpen(false)} aria-label="Close"><X size={16} /></button></div><form onSubmit={submitIncident}><div className="form-grid"><div className="form-field full"><label>Incident title</label><input required value={form.title} onChange={event => setForm({ ...form, title: event.target.value })} placeholder="e.g. Repeated SSH failures followed by successful admin login" /></div><div className="form-field full"><label>Description</label><textarea required value={form.description} onChange={event => setForm({ ...form, description: event.target.value })} placeholder="What was detected and why is it suspicious?" /></div><div className="form-field"><label>Source IP / origin</label><input value={form.sourceIp} onChange={event => setForm({ ...form, sourceIp: event.target.value })} placeholder="192.168.1.50" /></div><div className="form-field"><label>Target</label><input value={form.target} onChange={event => setForm({ ...form, target: event.target.value })} placeholder="prod-bastion-01" /></div><div className="form-field"><label>Username / identity</label><input value={form.username} onChange={event => setForm({ ...form, username: event.target.value })} placeholder="admin" /></div><div className="form-field"><label>Severity</label><select value={form.severity} onChange={event => setForm({ ...form, severity: event.target.value as Severity })}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="critical">Critical</option></select></div><div className="form-field"><label>Timestamp</label><input type="datetime-local" value={form.detectedAt} onChange={event => setForm({ ...form, detectedAt: event.target.value })} /></div><div className="form-field full"><label>Logs</label><textarea value={form.logs} onChange={event => setForm({ ...form, logs: event.target.value })} placeholder="Paste relevant logs, alert context, or event sequence" /></div><div className="form-field full"><label>Error messages / indicators</label><textarea value={form.errorMessages} onChange={event => setForm({ ...form, errorMessages: event.target.value })} placeholder="Policy violations, error messages, hashes, or other indicators" /></div></div><div className="form-actions"><button type="button" className="secondary-button" onClick={() => setCreateOpen(false)}>Cancel</button><button className="primary-button" disabled={createMutation.isPending}><Send size={14} /> {createMutation.isPending ? "Adding signal…" : "Add to investigation queue"}</button></div></form></aside></div>}
    </div>
  );
}

function MemoryView({ incidents, onSelect, onBack }: { incidents: any[]; onSelect: (id: number) => void; onBack: () => void }) {
  return <><section className="page-heading"><div><div className="eyebrow"><span className="pulse" /> Hindsight is the differentiator</div><h1>Memory, made operational</h1><p className="subhead">Structured incident knowledge keeps the next analyst from repeating the last investigation.</p></div><button className="secondary-button" onClick={onBack}><LayoutDashboard size={14} /> Back to command center</button></section><div className="full-view"><div className="panel"><div className="panel-head"><div className="panel-head-copy"><Library size={14} /><div><div className="panel-kicker">Resolved knowledge</div><h2>Previous incidents</h2></div></div><span className="status-chip resolved">{incidents.length} memories</span></div><div className="panel-body"><div className="memory-columns">{incidents.map(item => <button key={item.id} className="memory-item" onClick={() => onSelect(item.id)} style={{ textAlign: "left" }}><div className="item-row"><span className="item-code">{item.incidentCode}</span><SeverityPill severity={item.severity} /></div><div className="item-title">{item.title}</div><div className="item-meta"><span>{formatTime(item.detectedAt)}</span><span>·</span><span>{item.finalResolution ? "resolution captured" : "partial record"}</span></div></button>)}</div></div></div><div className="panel"><div className="panel-head"><div className="panel-head-copy"><BrainCircuit size={14} /><div><div className="panel-kicker">Remembered structure</div><h2>What Hindsight keeps</h2></div></div></div><div className="panel-body"><div className="lesson-card"><Fingerprint size={19} color="var(--success)" /><strong>Root causes become searchable patterns</strong><p>Credential abuse, phishing delivery, endpoint execution, and other patterns are attached to real evidence instead of stored as generic chat history.</p></div><div className="lesson-card" style={{ marginTop: 10 }}><FileSearch size={19} color="var(--accent)" /><strong>Actions are tied to outcomes</strong><p>Every recommended action is connected to what actually fixed a previous incident, so the analyst can approve, reject, or adapt it with context.</p></div><div className="lesson-card" style={{ marginTop: 10 }}><RefreshCw size={19} color="var(--warning)" /><strong>Resolved incidents close the loop</strong><p>The resolution form turns the current case into the next case's memory — investigation steps, final cause, and lessons learned.</p></div></div></div></div></>;
}

function RunbooksView() {
  const runbooks = [{ icon: LockKeyhole, title: "Privileged access compromise", copy: "Contain identity risk first, then preserve evidence.", steps: ["Revoke sessions", "Reset credential", "Enable MFA", "Review admin actions"] }, { icon: Network, title: "Suspicious endpoint execution", copy: "Keep the process tree and endpoint context intact.", steps: ["Isolate endpoint", "Collect volatile evidence", "Block hash / domain", "Hunt across fleet"] }, { icon: TerminalSquare, title: "SSH brute force", copy: "Separate noisy scanning from successful access.", steps: ["Review auth logs", "Validate source IP", "Check post-login commands", "Block confirmed source"] }, { icon: FlaskConical, title: "Phishing attachment", copy: "Trace delivery, execution, and identity exposure.", steps: ["Quarantine message", "Extract attachment hash", "Trace child process", "Rotate credentials"] }];
  return <><section className="page-heading"><div><div className="eyebrow"><span className="pulse" /> Response library</div><h1>Runbooks that remember</h1><p className="subhead">Actions are presented as operational patterns, ready to adapt when memory points to a familiar path.</p></div></section><div className="runbook-grid">{runbooks.map(({ icon: Icon, title, copy, steps }) => <div className="runbook-card" key={title}><div className="runbook-card-head"><div className="runbook-icon"><Icon size={15} /></div><div><h3>{title}</h3><p>{copy}</p></div></div><ul>{steps.map(step => <li key={step}>{step}</li>)}</ul></div>)}</div></>;
}

function LearningView({ incidents }: { incidents: any[] }) {
  const latest = incidents[0];
  return <><section className="page-heading"><div><div className="eyebrow"><span className="pulse" /> Close the feedback loop</div><h1>Learning loop</h1><p className="subhead">A resolved incident is not the end state. It is the next analyst's head start.</p></div></section><div className="full-view"><div className="panel"><div className="panel-head"><div className="panel-head-copy"><Sparkles size={14} /><div><div className="panel-kicker">Operational flywheel</div><h2>From case to context</h2></div></div></div><div className="panel-body"><div className="memory-flow" style={{ display: "grid", gap: 7 }}><div className="lesson-card"><strong>01 · Resolve</strong><p>Record what actually fixed the issue, not just what was suggested.</p></div><div className="lesson-card"><strong>02 · Structure</strong><p>Capture final root cause, evidence, actions taken, and the lesson learned.</p></div><div className="lesson-card"><strong>03 · Recall</strong><p>When a similar alert arrives, Hindsight surfaces this case beside the new signal.</p></div></div></div></div><div className="panel"><div className="panel-head"><div className="panel-head-copy"><CheckCircle2 size={14} /><div><div className="panel-kicker">Latest learned memory</div><h2>{latest?.incidentCode ?? "No memories yet"}</h2></div></div></div><div className="panel-body">{latest ? <><div className="lesson-card"><strong>{latest.title}</strong><p>{latest.lessonsLearned || "This memory is ready for a post-mortem note."}</p></div><div className="analysis-block"><div className="analysis-block-head"><span>What fixed it</span><span>resolution</span></div><p className="analysis-copy">{latest.finalResolution || "Resolution details will appear when the case is closed."}</p></div></> : <div className="empty-state"><Sparkles size={22} />Resolve an incident to seed the learning loop.</div>}</div></div></div></>;
}
